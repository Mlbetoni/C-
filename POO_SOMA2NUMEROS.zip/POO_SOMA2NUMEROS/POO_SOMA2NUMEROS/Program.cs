﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POO_SOMA2NUMEROS
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("\nProgramação Orientada a Objetos");
            Console.Write("\nSoma de 2 Números");

            // Instanciando a Classe clsSoma
            clsSoma objsoma = new clsSoma();

            // Solicita ao Usuário od dois números
            Console.Write("\nInforme o número1: ");
            int num5 = Convert.ToInt16(Console.ReadLine());
            Console.Write("\nInforme o número2: ");
            int num3 = Convert.ToInt16(Console.ReadLine());

            // Realiza a soma e exibe o resultado
            int result = objsoma.Somar(num5, num3);
            Console.Write("\nA soma é: " + result);

            Console.ReadKey();


            Console.ReadLine();
            
        }
       
           
    }
}
